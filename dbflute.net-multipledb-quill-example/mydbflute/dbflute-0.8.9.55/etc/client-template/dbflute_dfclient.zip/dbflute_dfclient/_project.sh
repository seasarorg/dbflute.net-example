#!/bin/bash

export ANT_OPTS=-Xmx512m

export DBFLUTE_HOME=../mydbflute/dbflute-0.8.9.55

export MY_PROJECT_NAME=dfclient

export MY_PROPERTIES_PATH=build.properties
